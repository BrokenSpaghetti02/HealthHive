
  # Jagna Health App Prototype

  This is a code bundle for Jagna Health App Prototype. The original project is available at https://www.figma.com/design/8UjQ821hVFjpS99giHHdR8/Jagna-Health-App-Prototype.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  